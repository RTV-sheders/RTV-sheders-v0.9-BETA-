// Purpose:
	// Main Shadow Vertex Shader:
		// puts vertexes into the view of the Sun or Moon, to create a shadow map
		// optionally voxelizes the scene ( usually done here, but can also be done in other gbuffer programs )
	
// Our Settings
	#include "/stuff/settings.glsl"

// Data from Minecraft / Iris
	in vec4 at_midBlock;
	uniform vec3 cameraPosition;
	attribute vec4 mc_Entity;
	uniform float frameTimeCounter;
	uniform int renderStage;
	uniform int entityId;
    // Iris item.properties ID for the item currently being rendered (including dropped item models).
    // Other shader loaders leave this optional uniform at zero, so no fake item emitters are created.
    uniform int currentRenderedItemId;
	uniform vec3 skyColor;
	
	//Space Transforms
		//are moved into #include "/stuff/space_transforms.glsl"

		
	// Textures / Images / Samplers
	uniform sampler2D gtexture;
	uniform sampler2D specular;
	//the 3d texture we are writing voxel data to
	layout (r32ui) uniform uimage3D cimage1;
	#include "/stuff/voxelizing/emitters.glsl"


//data we send to fragment shader
	out vec2 lmcoord;
	out vec2 texcoord;
	out vec4 glcolor;

//included files
	#include "/stuff/local_texture_coords.glsl"
 	#include "/stuff/uv_packing.glsl"
	#include "/stuff/voxelizing/voxel_lods.glsl"
	#define PACKING_VOXELS_HERE 1
	#include "/stuff/voxelizing/voxel_packing.glsl"
	#include "/stuff/space_transforms.glsl"


void main() {

	//standard stuff
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
	glcolor = gl_Color;

	
	//for voxelizing
	#define WHERE_TO_VOXELIZE 2 //[1 2]
	#if WHERE_TO_VOXELIZE == 2
		#include "/stuff/voxelizing/voxelizing.glsl"
	#endif
	
	
	//standard vertex transformation
	gl_Position = ftransform();
	
	//shadowmap distortion
	gl_Position.xyz = distort(gl_Position.xyz);

}

