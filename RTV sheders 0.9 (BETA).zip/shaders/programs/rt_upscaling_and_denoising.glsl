// MIT License: Do Whatever you want to with this code as long as this line stays in the file. This file contains code Copyright © 2026 timetravelbeard (contact: https://www.patreon.com/timetravelbeard , https://youtube.com/@timetravelbeard3588 , https://discord.gg/S6F4r6K5yU )  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


// RT Upscaling & Denoising (1 of 2 files)

// Purpose:
	// RT Upscale & Denoising: 
	
		// When running low res RT or Denoising:
			// the Primary Deferred Pass doen't add lighting to the scene, it defers it
			// this pass runs, or just the final one does. this pass may run twice before the final one
				// this pass samples the defered lighting and upscales/denoises it
				// it is later applied in a final denoising pass
		
		
	// This could be done a lot better, this is the simplest way to denoise lighting that I could think of


// Our Settings
	#include "/stuff/settings.glsl"

// Data from Minecraft / Iris
    uniform vec3 skyColor;
	uniform vec3 cameraPosition;
	uniform vec3 previousCameraPosition;
	uniform vec3 shadowLightPosition;
	uniform int frameCounter;
	uniform bool hideGUI;
	uniform ivec2 eyeBrightnessSmooth;
	uniform float viewWidth;
	uniform float viewHeight;
	uniform float near;
	uniform float far;

// Samplers / Textures / Images
	
	//depth
	uniform sampler2D  depthtex0;
	
	//working scene image
    uniform sampler2D colortex0; // scene image
	
	//defered data
    uniform sampler2D colortex1; // albedo
    uniform sampler2D colortex2; // specular tex 
    uniform sampler2D colortex3; // normals tex (in world space) 
    uniform sampler2D colortex4; // defered_data_1_tex; // vec4(lmcoord,ao,height_map);
	uniform sampler2D colortex5; // vec4 normals_face_world, float material_mask_id
	
	//the 3d texture we are writing voxel data to
	layout (r32ui) uniform uimage3D cimage1;
	//our 3d image with voxel data as an interpolated sampler
	uniform usampler3D cSampler1;
    
    #if THIS_DENOISING_PASS == 2
		//we have flagged the second pass, so that we can do things differently in it
			//the first pass needs to sample the (low res) trace Data in colortex6
			//the second pass needs to sample the upscaled data in colortex7, to process it again
			
        uniform sampler2D colortex7; // full res hdr lighting that is already partially upscaled/denoised
		// we are going to use a define trick to load from a different sampler without having to change the code after thos point 
        #define LIGHT_SAMPLER colortex7
		//we likewise change the variable we use for knowing the resolution of the input
        #define ACTIVE_RT_RESOLUTION_DIVIDER 1 
    #else
		//the first pass samples the (low res) colortex6, at its given resolution
        #define LIGHT_SAMPLER colortex6
        #define ACTIVE_RT_RESOLUTION_DIVIDER int(RT_RESOLUTION_DIVIDER)
    #endif

// Data from Vertex Shader
    in vec2 texcoord;
	
// Global variables
	vec3 Sun_or_moon_dir_world;
	vec3 Dither_offset;

// Outputs
	/* RENDERTARGETS:7 */
	layout(location = 0) out vec4 lighting_and_depth;
    const bool colortex7Clear = false;
	/*
	const int colortex7Format = RGBA16F;
	*/

// Included files 
	#include "/stuff/color/srgb_conversion.glsl"
	#include "/stuff/space_transforms.glsl"
	#include "/stuff/shadowmap_sampling.glsl"
	#define UNPACKING_VOXEL_UVS_HERE 1
	#include "/stuff/uv_packing.glsl"
	#include "/stuff/voxelizing/voxel_packing.glsl"
    #include "/stuff/rt/rt.glsl"
    #include "/stuff/noise/noise_texture.glsl"
	#include "/stuff/noise/noise_functions.glsl"
	#include "/stuff/reprojection.glsl"



// Functions
	void progress_dither()
	{
		#if TEMPORAL_ACCUMULATION > 0
			Dither_offset = fract(Dither_offset + random_from_vec2(gl_FragCoord.xy) );
		#endif
	}
	
	vec3 get_screen_dither()
	{	
		#if DITHER_TYPE == 1 || DITHER_TYPE == 3 
			return blue_noise().xyz;
		#endif
		#if DITHER_TYPE == 2
			return vec3(
				random_from_vec2(gl_FragCoord.xy),
				random_from_vec2(gl_FragCoord.xy*(1.238+texcoord)),
				random_from_vec2(gl_FragCoord.xy*(3.1497+texcoord))
				);
		#endif
	}
	
	float linearize_depth(in float d)
	{
		// from gl_FragCoord.z to world measurements
		return 2.0 * near  * far / (far + near - (2.0 * d - 1.0) * (far - near));
	}
	




// Main Function

void main()
{
	// This is just Copy-Pasted from the Deferred Primary Pass, and poorly pruned
	
	
	// Setup
	
		vec3 Debug_value; //so we can debug locally coped stuff at the end of the function
		
		#if RAYTRACING_VIEW == 1
			//we are ray tracing the right half of the screen, so ignore it here
			if(texcoord.x<=.5)
			{
		#endif
		#if RAYTRACING_VIEW == 2
			//we are ray tracing the entire screen, so ignore it here
			if(false)
			{
		#endif
        
    // Load data and unpack
		float depth_tex_read = texture(depthtex0,texcoord).r;
		bool primary_ray_hit = depth_tex_read<1.;
        #if DENOISE_REFRACTIONS == 0
		    vec4 albedo = texture(colortex1, texcoord);
        #endif
		vec4 specular_tex = texture(colortex2, texcoord);
		//vec4 defered_data_1_tex = texture(colortex4, texcoord);
		//vec2 lmcoord = defered_data_1_tex.xy;
		vec4 deferred_data2 =  texture(colortex5, texcoord);
		vec3 normals_face_world = deferred_data2.xyz;
		float material_mask_id = deferred_data2.a;
		vec3 normals_texture_world = texture(colortex3, texcoord).xyz;
		
		//unpack 
		//albedo.rgb = srgb_to_linear(albedo.rgb);
		float sss = specular_tex.b < 64.5? specular_tex.b/64. : 0.;
		
		float emmission = specular_tex.a * BLOCK_LIGHT_BRIGHTNESS; //emission

	// Setup
	    
		vec3 view_dir_world;
		   { //scoped to remove variables from memory as soon as we don't need them anymore
				vec3 direction_screen = vec3(texcoord, 1.);
				vec3 direction_view = screen_to_view_space(direction_screen);
				view_dir_world = normalize( view_to_foot_direction(direction_view) );
			}

		// fix imposible viewing angles from normal textues that point away from the camera
		if( dot(normals_texture_world,view_dir_world) > 0. )  normals_texture_world = normals_face_world;

		#if USE_TEXTURE_NORMALS == 0
			normals_texture_world = normals_face_world;
		#endif
		
		vec3 foot_pos;
		   { //scoped to remove variables from memory as soon as we don't need them anymore
				vec3 position_screen = vec3(texcoord, depth_tex_read);
				vec3 position_view = screen_to_view_space(position_screen);
				foot_pos = view_to_foot_space(position_view);
			}

		//Load a Dither / Randomness / Offset
		Dither_offset = get_screen_dither();
		//change per frame
		#if TEMPORAL_ACCUMULATION > 0
			#if TEMPORAL_ACCUMULATION == 1
				if(hideGUI) Dither_offset = fract(Dither_offset+float(frameCounter % 997)*0.61803398875);
			#else
				Dither_offset = fract(Dither_offset+float(frameCounter % 997)*0.61803398875);
			#endif
		#endif
			
				
		//Load & Upscale Lighting
		vec4 lighting_and_depth_last = texture(LIGHT_SAMPLER,texcoord);
		#if RTV_PHONE == 1
			// phone: bad light data never gets copied through (depth below is passed on untouched)
			lighting_and_depth_last.rgb = rtv_safe3(lighting_and_depth_last.rgb, 10000.);
			lighting_and_depth_last.a = rtv_safe1(lighting_and_depth_last.a, 100000.);
		#endif

		#if RT_DENOISING == 1
			// we will manually blend between neighboring samples
			
			//load samples around this point
			ivec2 uv = ivec2(gl_FragCoord.xy);
			ivec2 depth_size = textureSize(depthtex0, 0);
			ivec2 depth_max_uv = max(depth_size - ivec2(1), ivec2(0));
			ivec2 light_size = textureSize(LIGHT_SAMPLER, 0);
			ivec2 light_max_uv = max(light_size - ivec2(1), ivec2(0));
									
			//weigh thier similarity and blend, according to these rules
			
			//initialize the sample pool
			float total_weight = 0.;
			vec3 sampled_color = vec3(0.);
							
			//loop through neighboring pixels
			for(int x = -RT_DENOISING_KERNEL_SIZE ; x<= RT_DENOISING_KERNEL_SIZE ; x++)
			{
				for(int y = -RT_DENOISING_KERNEL_SIZE ; y<= RT_DENOISING_KERNEL_SIZE ; y++)
				{
					// water: the see-through image (sea floor) must stay sharp, so water pixels only blend with their nearest neighbors
					if (abs(material_mask_id - 1.0) < 0.5 && max(abs(x), abs(y)) > WATER_DENOISE_RADIUS) continue;
					//kernel blur 
					float kblur = max(0.0, 1.0 - KERNEL_FADE * (abs(x) + abs(y)) / float(max(1, RT_DENOISING_KERNEL_SIZE + RT_DENOISING_KERNEL_SIZE)));

					//neighboring pixel to sample

                    ivec2 n_uv = uv + ivec2(x, y)
                        #if THIS_DENOISING_PASS == 1 && DENOISING_PASSES >= 3
                            * max(1, ACTIVE_RT_RESOLUTION_DIVIDER * 2);
                        #else
                            * max(1, ACTIVE_RT_RESOLUTION_DIVIDER);
                        #endif
                    n_uv = clamp(n_uv, ivec2(0), depth_max_uv);
                    ivec2 light_uv = clamp(n_uv / ACTIVE_RT_RESOLUTION_DIVIDER, ivec2(0), light_max_uv);

                    // Screen-edge-safe sampling: surface data uses full resolution, RT light uses its active resolution.
                    vec3 lighting_sample2 = RTV_SAFE3(texelFetch(LIGHT_SAMPLER, light_uv, 0).rgb, 10000.);
                    vec3 normals2 = texelFetch(colortex3, n_uv, 0).rgb;
                    float depth_tex_read2 = texelFetch(depthtex0, n_uv, 0).r;
                    float neighbor_material_mask_id = texelFetch(colortex5, n_uv, 0).a;

                    // Water-edge fringe guard: never denoise water with shoreline/terrain samples.
                    // This also prevents land pixels from pulling blue water into their edges.
                    float center_is_water = 1.0 - step(0.5, abs(material_mask_id - 1.0));
                    float neighbor_is_water = 1.0 - step(0.5, abs(neighbor_material_mask_id - 1.0));
                    float water_region_match = 1.0 - abs(center_is_water - neighbor_is_water);

                    // Water-only bilateral weighting preserves colour boundaries in reflected silhouettes.
                    // The branch keeps the extra colour math off non-water pixels.
                    float water_reflection_edge_weight = 1.0;
                    if (center_is_water > 0.5)
                    {
                        vec3 center_water_color = max(RTV_SAFE3(lighting_and_depth_last.rgb, 10000.0), vec3(0.0));
                        float center_water_luma = dot(center_water_color, vec3(0.2126, 0.7152, 0.0722));
                        float sample_water_luma = dot(max(lighting_sample2, vec3(0.0)), vec3(0.2126, 0.7152, 0.0722));
                        float water_luma_edge = abs(log2(1.0 + center_water_luma) - log2(1.0 + sample_water_luma));
                        vec3 center_water_chroma = center_water_color / max(center_water_luma, 0.05);
                        vec3 sample_water_chroma = max(lighting_sample2, vec3(0.0)) / max(sample_water_luma, 0.05);
                        float water_chroma_edge = min(length(center_water_chroma - sample_water_chroma), 2.0);
                        water_reflection_edge_weight = 1.0 - 0.75 * smoothstep(0.30, 0.95, water_luma_edge + 0.18 * water_chroma_edge);
                    }
					
					// Keep first-person hand/item samples separate from the world behind them.
					float center_is_hand = step(100.5, abs(material_mask_id));
					float neighbor_is_hand = step(100.5, abs(neighbor_material_mask_id));
					float hand_region_match = 1.0 - abs(center_is_hand - neighbor_is_hand);
                    // Mask 100 is a mob/entity; do not mix its denoising samples with terrain.
                    float center_is_entity = 1.0 - step(0.5, abs(material_mask_id - 100.0));
                    float neighbor_is_entity = 1.0 - step(0.5, abs(neighbor_material_mask_id - 100.0));
                    float entity_region_match = 1.0 - abs(center_is_entity - neighbor_is_entity);

					//compare
					float w = kblur* // kernel blur/fade on edges
						pow( max(0., dot(normals2,normals_texture_world) ),RT_DENOISING_NORMALS_EXP) // normals weight
						* max(0., 1. - abs(linearize_depth(depth_tex_read2)-linearize_depth(depth_tex_read)) / (0.25 + 0.10*linearize_depth(depth_tex_read)) ) // depth weight, relative to distance so slopes and far areas still get denoised
						* hand_region_match
						* entity_region_match
						* water_region_match
						* water_reflection_edge_weight
						;
						
					//add to sample pool
					if (x == 0 && y == 0) w = max(w, 0.0001);
					sampled_color += lighting_sample2 * w;
					total_weight += w;
				}
			}
			
			//normalize the sample
			lighting_and_depth = vec4(
                clamp( sampled_color/max(total_weight,0.001) ,0., 10000.) ,
                lighting_and_depth_last.a); //the depth is passed untouched

		#endif
        
        #if DENOISE_REFRACTIONS == 0
            if(albedo.a<.999) lighting_and_depth.rgb = lighting_and_depth_last.rgb;
        #endif

	
	#if RAYTRACING_VIEW > 0
        }//> close scope of where we ignore part of the screen that are going to be full RT view
//		else{
//			color=vec4(0.);//just write black here if you want to write something, it might become garbage data if you don't, I don't know
//		}
	#endif
	
	
	//Debug Area
		//color.rgb = fract(view_dir_world.rgb*10.);
		//color.rgb = fract(foot_pos+cameraPosition);
		//color.rgb = normals_face_world;
		//color.rgb = Dither_offset;
		//color.rgb = vec3( fract( linearize_depth(depth_tex_read) ) );
		//color.rgb = .5+.5*normals_texture_world;
		//color.rgb = vec3( fract( linearize_depth(depth_tex_read)/far ) );
	
}


