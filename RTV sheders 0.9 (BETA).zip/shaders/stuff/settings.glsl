// RTV: Mobile profile quality (phones via Java launchers, MobileGlues / ANGLE)
// MOBILE_MODE is no longer selectable (the Mobile profile was removed). It stays at 0.
#define MOBILE_MODE 0
#define MOBILE_DEBUG_VIEW 0

// RTV_PHONE = 1 when running on a phone: MobileGlues sets MG_MOBILEGLUES by itself, and the Mobile profile
// sets MOBILE_MODE. Everything guarded by RTV_PHONE is a phone-only safety fix. On desktop Java both are
// off, so the compiled code is identical to the original.
#if defined(MG_MOBILEGLUES) || MOBILE_MODE == 1
    #define RTV_PHONE 1
#else
    #define RTV_PHONE 0
#endif

// RTV: stable world lighting and day/night response
// Iris / Minecraft world time, in ticks (0-23999).
uniform int worldTime;
#define NIGHT_LIGHTING_STRENGTH 0.80 //[0.25 0.5 0.65 0.8 1.0 1.2 1.5]

float rtv_day_cycle()
{
    float ticks = mod(float(worldTime), 24000.0);
    return cos((ticks - 6000.0) * (6.28318530718 / 24000.0));
}

// Keep moonlight present, but prevent the sun's daytime intensity from making nights bright.
float rtv_sunlight_factor()
{
    float day_curve = max(rtv_day_cycle(), 0.0);
    float day_strength = smoothstep(0.0, 0.12, day_curve);
    return mix(0.025 * NIGHT_LIGHTING_STRENGTH, 1.0, day_strength);
}

float rtv_sky_illumination_factor()
{
    float day_curve = max(rtv_day_cycle(), 0.0);
    float day_strength = smoothstep(0.0, 0.10, day_curve);
    return mix(0.035 * NIGHT_LIGHTING_STRENGTH, 1.0, day_strength);
}

// The sun stays neutral at noon.  Near the horizon it becomes gently warm,
// with a slightly more orange evening than morning; the low blend amount keeps
// white blocks white instead of turning the whole world into an orange filter.
vec3 rtv_sun_color()
{
    float ticks = mod(float(worldTime), 24000.0);
    float day_curve = max(rtv_day_cycle(), 0.0);
    float daylight = smoothstep(0.0, 0.22, day_curve);
    float horizon = daylight * (1.0 - smoothstep(0.10, 0.50, day_curve));
    float evening = smoothstep(6000.0, 12000.0, ticks);
    vec3 horizon_tint = mix(vec3(1.0, 0.91, 0.76), vec3(1.0, 0.84, 0.64), evening);
    return mix(vec3(1.0), horizon_tint, horizon * 0.62);
}


// Match the procedural sky to the original v0.7 world colour temperature.
// 0.00 = fully procedural palette; 1.00 = original Minecraft skyColor/fogColor response.
#define SKY_TEMPERATURE_MATCH 0.65 //[0.00 0.25 0.40 0.50 0.65 0.75 1.00]

//Color grading: soft saturation & vibrance (applied at the very end, after tonemapping)
#define SATURATION 1.08 //[0.80 0.90 1.00 1.05 1.10 1.15 1.20 1.30 1.40]
#define VIBRANCE 0.15 //[0.00 0.10 0.15 0.20 0.30 0.40 0.50 0.70 1.00]
#define CONTRAST 1.04 //[0.90 0.95 1.00 1.02 1.04 1.06 1.08 1.10]

// Saturation boosts all colors evenly; vibrance boosts dull colors more than already-vivid ones,
// so the image gets richer without neon/oversaturated spots.
vec3 rtv_color_grade(vec3 c)
{
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    float mx = max(c.r, max(c.g, c.b));
    float mn = min(c.r, min(c.g, c.b));
    float current_sat = (mx - mn) / (mx + 0.0001);
    c = mix(vec3(luma), c, SATURATION);
    c = mix(vec3(luma), c, 1.0 + VIBRANCE * (1.0 - current_sat));
    // Keep highly lit foliage and snow from turning into clipped neon colour.
    // Midtones retain their saturation; only the brightest values roll gently toward neutral.
    float highlight_luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    float highlight_desaturation = 0.14 * smoothstep(0.62, 0.96, highlight_luma);
    c = mix(c, vec3(highlight_luma), highlight_desaturation);
    c = (c - 0.5) * CONTRAST + 0.5;
    return clamp(c, 0.0, 1.0);
}

//Water presentation: animated surface normals and controlled ray-traced reflections.
#define WATER_WAVE_STRENGTH 0.045 //[0.00 0.02 0.03 0.04 0.045 0.055 0.07 0.10 0.12 0.13 0.14]
#define WATER_WAVE_SPEED 0.35 //[0.15 0.25 0.35 0.40 0.55 0.70 0.85 1.00 1.25]
#define WATER_WAVE_STYLE 1 //[0 1]
#define WATER_TINT 0.52 //[0.0 0.15 0.30 0.45 0.52 0.70 0.85 1.0]
#define WATER_ABSORPTION 1.5 //[0.5 1.0 1.4 1.5 1.8 2.5 3.5 5.0]
#define WATER_HISTORY_MAX 0.70 //[0.0 0.30 0.50 0.70 0.85 0.97]
#define WATER_DENOISE_RADIUS 1 //[0 1 2 3 4]
#define WATER_REFLECTION_STRENGTH 0.12 //[0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.20]

//Voxelizing    
    #define VISUALIZED_DATA 6 //[0 1 2 3 4 5 6]
    #define VOXEL_AREA 128 //[32 64 128]

    //set the voxelizing distance that isn't culled off-screen
    #if VOXEL_AREA == 32
        const float voxelDistance = 32.0;
    #endif
    #if VOXEL_AREA == 64
        const float voxelDistance = 64.0;
    #endif
    #if VOXEL_AREA == 128
        const float voxelDistance = 128.0;
    #endif

//RT
    #define RAYTRACING_VIEW 0 //[0 1 2]
    #define VOXELIZED_DEBUG_VIEW 0 //[0 1]
    #define SHADOWS_USED_ON_SCREEN 2 //[0 1 2]
    #define SUN_WIDTH 3.0 //[0.001 0.002 0.003 0.004 0.005 0.007 0.01 0.02 0.03 0.04 0.05 0.06 0.07 0.08 0.09 0.1 0.2 1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0]

    #define USE_TEXTURE_NORMALS 1 //[0 1]
    //Textures in RT
	#define TEXTURES_IN_RT 2 //[0 2 3 5]
	#define IPBR_MIRRORS 1 //[0 1]
	
	//part 5
    #define VOXEL_LODS 1 //[0 1 2 3]
    #define VOXEL_LOD_SQUARE 1 //[0 1]
	
	//part 6
	
	//Shadows - part 7
	#define SOFT_SHADOWMAP_SHADOWS 1 //[0 1]
	#define COLORED_SHADOWS_SHADOWMAP 1 //[0 1]
	#define SHADOW_SMOOTH_PCF 1 //[0 1]
	#define SHADOW_SOFTNESS 0.75 //Balanced PCF width: softer contact edges while preserving block and foliage shape. [0.25 0.5 0.75 1.0 1.5 2.0 2.5 3.0 4.0]
	#define SHADOW_FILTER_SAMPLES 4 //Kept for menu compatibility; classic PCF always uses a stable 3x3 grid. [4 6 8 12 16]
	#define GLASS_TINT_EXPONENT 0.35 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
	#define SHADOWS_IN_VOXEL_SCENE 2 //[0 1 2]
    #define SOFT_RT_SHADOWS 0 //[0 1]
    
    #define NO_MIPS_IN_ALPHA 1 //[0 1]
    #define COLORED_RT_SHADOWS 1 //[0 1]
	#define RT_SHADOW_TEXTURES 0 //[0 1]

	//part 8 - Color Spaces
	#define TONEMAPPING 1 //[0 1]
	#define BLOCK_LIGHT_BRIGHTNESS 72.0 //[1.0 3.0 10.0 40.0 60.0 72.0 100.0 110.0 150.0 200.0 300.0]
	#define RT_BLOCK_LIGHT_NEE 1 //[0 1]
	#define RT_BLOCK_LIGHT_SEARCH 2 //[1 2 3 4 5]
	#define RT_BLOCK_LIGHT_BOOST 1.10 //[0.6 0.8 1.0 1.1 1.2 1.5 2.0 3.0]
    // Preserve emitter hue fully: saturated sources stay red/cyan/green instead of mixing toward white or torch-orange.
    #define RT_BLOCK_LIGHT_COLOR_STRENGTH 1.0 //[0.0 0.25 0.50 0.65 0.82 1.0]
	#define BLOCK_LIGHT_SATURATION 1.00 //v0.7 colour temperature: preserve the natural warm/cool emitter hue without extra saturation. [1.00 1.15 1.30 1.40 1.55 1.75 2.00]
	#define EMISSION_SATURATION 1.00 //v0.7 glow colour response: no extra saturation; keep warm torch and cool/coloured emitters natural. [1.00 1.15 1.30 1.50 1.75 2.00]
	#define FAR_GI 1 //Edge-aware far-field GI/AO fill beyond the finite RT voxel volume, so distant terrain keeps shading. [0 1]
    // A secondary, visibility-tested RT sample carries coloured block-light energy into GI/reflection hits.
    #define RT_BLOCK_LIGHT_BOUNCE 1 //[0 1]
    #define RT_BLOCK_LIGHT_BOUNCE_STRENGTH 0.62 //[0.10 0.20 0.30 0.42 0.50 0.55 0.62 0.65 0.80 0.85 1.00 1.20]
    // Flame flicker of torches / candles / soul fire (coloured sources up to light level 14). White lamps and level-15 blocks never flicker. 0 = off.
    #define RT_BLOCK_LIGHT_FLICKER 0.50 //[0.00 0.25 0.50 0.75 1.00]
    // Mirror-like surfaces (metal, ice, glass, water): faint ambient that lets a reflection show its surroundings even in the dark,
    // and a floor for how much of the outside sky a reflected ray that escapes the voxel scene still sees.
    #define REFLECTION_AMBIENT 0.60 //[0.00 0.20 0.40 0.60 0.90 1.20 1.80]
    #define REFLECTION_ENV_FLOOR 0.20 //[0.035 0.10 0.20 0.35 0.50]
	#define RT_BLOCK_LIGHT_REACH 0.00 //[0.0 0.1 0.2 0.3 0.5 0.8]
	#define RT_BLOCK_LIGHT_RADIUS 8.0 //[4.0 5.0 6.0 7.0 8.0 9.0]
	#define RT_BLOCK_LIGHT_SOFTNESS 0.48 //Small physical source: stable torch shadows without oversized soft blobs. [0.12 0.2 0.3 0.4 0.48 0.6 0.8]
	// Dynamic lighting: torches, lanterns, glowstone etc. held in the main / off hand light up the world (ray traced, with shadows).
	#define HELD_LIGHT 1 //[0 1]
	#define HELD_LIGHT_BRIGHTNESS 1.0 //[0.5 0.75 1.0 1.25 1.5 2.0]
	// Glow of emissive blocks / textures (lamps, lava...). It is added after the denoiser, so it can no longer bleed into neighbouring pixels as a halo.
	#define EMISSION_STRENGTH 2.0 //[1.0 1.25 1.5 1.75 2.0 2.5 3.0 4.0]
	#define RT_BLOCK_LIGHT_WRAP 0.0 //No fake light through walls; indirect RT provides the bounce. [0.0 0.05 0.08 0.12 0.18 0.25 0.35]
	#define AO_MODE 1 //[0 1]
	#define AO_STRENGTH 0.90 //[0.25 0.5 0.65 0.75 0.85 0.90 1.0]
	#define AO_RADIUS 2.4 //[0.5 1.0 1.5 2.0 2.4 2.7 3.0]
	#define AO_SUN_MIX 0.42 //[0.0 0.15 0.25 0.35 0.42 0.50 0.70]
    // Shadowed mobs receive sky ambient fill, while a separate contact AO keeps body details grounded.
    #define ENTITY_SHADOW_FILL 0.28 //[0.15 0.20 0.25 0.28 0.35 0.40 0.48 0.55]
    #define ENTITY_AO_STRENGTH 0.72 //[0.35 0.45 0.55 0.60 0.68 0.72 0.85]
    #define ENTITY_AO_RADIUS 1.55 //[0.75 1.0 1.25 1.5 1.55 1.8 2.0]
	// Underwater: preserve visibility in shallow water with clear water fog and caustics.
	#define UNDERWATER_VISIBILITY 3.0 //[0.75 1.0 1.5 2.0 2.5 3.0]
	#define UNDERWATER_FOG_STRENGTH 0.30 //[0.10 0.20 0.30 0.40 0.50 0.65 0.85]
	#define UNDERWATER_CAUSTICS_STRENGTH 1.15 //[0.00 0.35 0.50 0.75 0.90 1.00 1.15 1.30]
	#define UNDERWATER_PARTICLES 0.50 //[0.00 0.25 0.50 0.75 1.00 1.50 2.00]
	#define UNDERWATER_VIGNETTE 0.40 //[0.00 0.25 0.40 0.50 0.75 1.00 1.50 2.00]
	#define UNDERWATER_SURFACE_WINDOW 1.00 //[0.00 0.50 1.00 1.50 2.00]
	// God Rays are removed; underwater fog and caustics remain independent.
	// Glowing things
	#define GLOWING_ORES 1 //[0 1]
	#define GLOWING_ORES_STRENGTH 0.22 //[0.08 0.14 0.22 0.32 0.45]
	#define PULSING_BLOCKS 1 //Crying obsidian pulses, amethyst shimmers, sculk breathes. [0 1]
	#define HELD_ITEM_GLOW 1 //[0 1]
	#define PARTICLE_GLOW 1.0 //Flames, portal, enchanting, fireworks, dragon breath... [0.0 0.5 1.0 1.5 2.0]
	// Sky
	#define PROCEDURAL_SKY 1 //[0 1]
	#define CLOUD_LAYERS 1 //Extra mid-altitude layer (altocumulus) between the cumulus and the cirrus. [0 1]
	// Light bounced from water onto walls and ceilings
	#define WATER_LIGHT_ON_WALLS 1 //[0 1]
	#define WATER_LIGHT_ON_WALLS_STRENGTH 1.0 //[0.25 0.5 0.75 1.0 1.5 2.0]
	// Clouds: 0 = vanilla clouds, 1 = volumetric cumulus clouds
	#define CLOUD_STYLE 1 //[0 1]
	#define CLOUD_COVERAGE 0.62 //[0.30 0.40 0.50 0.62 0.72 0.85 1.00]
	#define CLOUD_DENSITY 1.0 //[0.5 0.75 1.0 1.4 2.0 3.0]
	#define CLOUD_HEIGHT 190 //[120 150 170 190 220 260 320]
	#define CLOUD_THICKNESS 220 //[40 60 80 110 150 180 220 260 320]
	#define CLOUD_SPEED 1.0 //[0.0 0.25 0.5 1.0 1.5 2.0 3.0]
	#define CLOUD_BRIGHTNESS 1.0 //[0.6 0.8 1.0 1.2 1.5]
	#define CLOUD_QUALITY 3 //[1 2 3]
	#define CIRRUS_CLOUDS 1 //[0 1]
	#define CIRRUS_AMOUNT 1.0 //[0.5 0.75 1.0 1.25 1.5]
	#define CLOUD_COVERAGE_VARIATION 1.0 //[0.0 0.5 1.0 1.5]
	#define SUN_BRIGHTNESS 180.0 //[1.0 3.0 10.0 100.0 150.0 180.0 200.0 300.0 400.0 500.0 600.0]
	#define SUN_SURFACE_STRENGTH 0.78 //[0.55 0.65 0.72 0.78 0.85 0.92 1.00]
	#define SKY_BRIGHTNESS_IN_RT 0.3 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
    // v0.7 ambient baseline: enclosed rooms stay dark; only a very small sky-access floor remains.
    #define ROOM_AMBIENT_STRENGTH 0.008 //[0.00 0.005 0.008 0.012 0.02 0.035 0.045 0.06]
    // v0.7 ambient baseline: low-energy sky contribution on secondary hits; caves stay dark.
    #define GI_SKY_BOUNCE_STRENGTH 0.045 //[0.00 0.01 0.02 0.035 0.045 0.05 0.08 0.10 0.14 0.18]
	#define EXPOSURE 0 //[0 1 2 3 4 5 6 7 8 9 10 15 20 30 40 50 100]

	
	//part 9 - Global Illumination & Block light Shadows
	#define GLOBAL_ILLUMINATION 2 //[0 2]
	#define GI_STRENGTH 1.53 //[0.75 1.00 1.15 1.20 1.28 1.40 1.42 1.50 1.53 1.65 1.80 2.10 2.50]
	// Extra headroom for bright sunlit surfaces to illuminate nearby surfaces through the traced diffuse bounce.
	#define GI_DIFFUSE_BOUNCE_CAP 0.28 //[0.16 0.20 0.22 0.26 0.28 0.30 0.32 0.35 0.40]
	// Saturation is applied only to ray-traced diffuse bounce radiance, never to the full-screen grade.
	#define GI_BOUNCE_SATURATION 1.14 //[0.80 0.90 1.00 1.10 1.14 1.15 1.25 1.40]
	// Locked off: direct and indirect illumination come from traced emitters,
	// sunlight and sky rays only, never from the vanilla light-map fill.
	#define VANILLA_BLOCK_LIGHT_IN_RT 0
	#define VANILLA_SKY_LIGHT_IN_RT 0
	#define VANILLA_BLOCK_LIGHT_ON_SCREEN 0
	#define VANILLA_SKY_LIGHT_ON_SCREEN 0
	
	//part 10 - Temporal Accumulation & Reprojection
	#define TEMPORAL_ACCUMULATION 2 //[0 1 2]
	#define TEMPORAL_ACCUMULATION_MAX 0.97 //[0.5 0.7 0.8 0.85 0.9 0.92 0.95 0.97 0.98 0.99 1.0]
	#define DITHER_TYPE 3 //[1 2 3]
	#define DEBUG_TA 0 //[0 1]
	#define TA_IS_PBR_AWARE 1 //[0 1]
	#define TA_MOBS 1 //[0 1]
	#define TA_HAND 1 //[0 1]
	#define TA_PBR_REJECTION_EXPONENT 5.0 //[1.0 1.2 1.5 1.7 2.0 3.0 4.0 5.0 10.0]
	
	#define TA_BOOTUP_DELAY 10 //[0 1 5 10 20 50]

	//Part 11 - Upscaling & Denoising for Faster & Cleaner RT
	#define RT_RESOLUTION_DIVIDER 1 //[1 2 4 10 20 100]
	#define RT_DENOISING 1 //[1]
	// Wider spatial kernel suppresses residual GI speckles. 9 = 19x19; Extreme can use 11 = 23x23.
	#define RT_DENOISING_KERNEL_SIZE 9 //[1 2 3 4 5 6 7 8 9 10 11]
	#define KERNEL_FADE 0.32 //[0.1 0.2 0.25 0.3 0.32 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
    #define DENOISING_PASSES 2 //[2]
    #define RT_DENOISING_NORMALS_EXP  4.0 //[1.0 1.5 2.0 3.0 4.0 5.0 7.0 10.0 20.0]
    // Recover only stronger luminance detail after filtering; the dead-zone avoids restoring tiny noise speckles.
    #define RT_DENOISING_SHARPEN 0.22 //[0.0 0.05 0.10 0.15 0.20 0.22 0.25 0.30]

	//Part 12 - Glass & Refraction
	#define GLASS_REFRACT_INDEX 0.67 //[0.2 0.3 0.4 0.5 0.6 0.67 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6]
	#define ICE_REFRACT_INDEX 0.76 //[0.5 0.6 0.7 0.76 0.8 0.9 1.0]
	// Light (block light, sun, moon) that passes through coloured glass takes the colour of the glass.
	#define GLASS_LIGHT_TINT 2.0 //[0.0 0.5 1.0 1.5 2.0 3.0]
	// Small ripple in the coloured light behind glass (glass is never perfectly flat).
	#define GLASS_LIGHT_DISTORTION 0.6 //[0.0 0.3 0.6 1.0 1.5]
	#define GLASS_DISTORTION 0.08 //[0.0 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.20 0.30]
	// Visible but controlled dielectric reflections for clear glass, stained glass and thin panes.
	#define GLASS_REFLECTION_STRENGTH 0.13 //[0.06 0.08 0.10 0.12 0.13 0.15 0.18 0.22]
	// Subtle cool-white body tint so clear / white glass catches highlights without looking opaque.
	#define CLEAR_GLASS_TINT 0.075 //[0.00 0.03 0.05 0.075 0.10 0.14]
	#define RT_GLASS_TINTING 0 //[0 1]
    #define TA_REFRACTIONS 1 //[0 1]
    #define DENOISE_REFRACTIONS 1 //[0 1]

// ---------------------------------------------------------------------------
// Phone safety helpers (RTV_PHONE only).
// Phone GPUs hand out UNINITIALIZED memory for new buffers (desktop drivers give zeros). The history /
// light buffers are never cleared, so the first frame can read NaN / Inf / random values, and
// mix(a, NaN, 0.0) is still NaN, so one bad pixel poisoned the whole image with colorful speckles.
// A value is accepted only if it passes the comparison tests (NaN and Inf always fail them).
// ---------------------------------------------------------------------------
#if RTV_PHONE == 1
    float rtv_safe1(float x, float mx) { return (x >= 0.0 && x <= mx) ? x : 0.0; }
    vec3 rtv_safe3(vec3 c, float mx) { return vec3(rtv_safe1(c.x, mx), rtv_safe1(c.y, mx), rtv_safe1(c.z, mx)); }
    bool rtv_valid1(float x, float mx) { return x >= 0.0 && x <= mx; }
    bool rtv_valid3(vec3 c, float mx) { return rtv_valid1(c.x, mx) && rtv_valid1(c.y, mx) && rtv_valid1(c.z, mx); }
    #define RTV_CLAMP3(c, mx) rtv_safe3((c), (mx))   // replaces an existing clamp(c, 0., mx)
    #define RTV_SAFE3(c, mx) rtv_safe3((c), (mx))    // new check on a value that was read raw before
    #define RTV_SAFE_NEE(c) rtv_safe3((c), 100000.)
#else
    #define RTV_CLAMP3(c, mx) clamp((c), 0., (mx))
    #define RTV_SAFE3(c, mx) (c)                     // desktop: untouched
    #define RTV_SAFE_NEE(c) (c)
#endif

