// MIT License: Do Whatever you want to with this code as long as this line stays in the file. This file contains code Copyright © 2026 timetravelbeard (contact: https://www.patreon.com/timetravelbeard , https://youtube.com/@timetravelbeard3588 , https://discord.gg/S6F4r6K5yU )  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

#if RT_API == 4

//DDA Trace with LOD bitmask


// Dependencies
	#include "/stuff/voxelizing/voxel_lods.glsl"


// Settings

    #define V_TRACE_BIAS 0.001


// Data Structures

struct Traced_ray{
    vec3 pos;
    bool hit_something;
    vec3 normals_face;
    vec3 dir;
    vec2 uvs;
//temp
    vec4 albedo;
    
};



// Functions

Traced_ray trace_ray(in vec3 pos, in vec3 dir)
{
    //initiate
    Traced_ray this_ray;
    this_ray.hit_something = false;
    
    //convert to voxel space
    pos+=VOXEL_AREA/2+fract(cameraPosition);

    //these variables are function wide because they're used in trace and uv hit sections
    ivec3 v_normal;
    ivec3 voxel_pos=ivec3(-1);
    ivec3 last_lod1=ivec3(-1);;
    uint lod_chunk=1u;
    uint lod_chunk2=1u;
	vec3 dda_pos;
	ivec3 last_dda_pos;

    #if VOXEL_LOD_SQUARE == 1  
        const ivec3 LOD_box_size = ivec3(4,4,4);
    #endif

    //trace ray
    bool in_bounds=true;
    for(int steps = 0; steps < RT_STEPS && !this_ray.hit_something && in_bounds ; steps ++)
    {
        
         //calculate dda
            float trace_size = lod_chunk+lod_chunk2 == 0u?4.:1.;//in an empty chunk, we can go through the whole thing
            dda_pos = pos/trace_size;//get into a dda-sized space
            vec3 a;//step distance in dda space
            {
	            vec3 d = sign(dir);
	            a = //get the distance to the edge in all 3 directions
			        vec3(
			             (sign(d.x)>0. ?
                       	    1.-fract(dda_pos.x)
                       		: fract(dda_pos.x)
			             )
			            ,
			             (sign(d.y)>0. ?
                       	    1.-fract(dda_pos.y)
                       		: fract(dda_pos.y)
			             )
			            ,
			             (sign(d.z)>0. ?
                       	    1.-fract(dda_pos.z)
                       		: fract(dda_pos.z)
			             )
			            );
                 a+=1-abs(sign(a)); //fix cracks when it is 0 distance to an edge by ignoring that direction
			     a/=max(vec3(0.001),abs(dir)); //how many steps to reach each edge at current velocity
			     a.x= min( min(a.x,a.y),a.z)+V_TRACE_BIAS;//take the smallest amount of steps to an edge, plus a bias to go into it
             }

        //save last position to tell which side of a block we are going to hit
            last_dda_pos = ivec3(dda_pos);

        //increment ray by DDA amount
		    dda_pos+= a.x*dir.xyz;
            pos = dda_pos*trace_size;//exit dda-sized space


        //check for hit and out of bounds
        voxel_pos = ivec3(pos);
        in_bounds = ( clamp(voxel_pos,0,VOXEL_AREA-1) == voxel_pos);

	    if(in_bounds)
        { //if inside Voxel Area

            #if VOXEL_LODS > 0 
             
                //which LOD chunk to check

                #if VOXEL_LOD_SQUARE == 1  
                            
                      ivec3 lod1 = voxel_pos / Voxel_bitmask_lod_size;
                      ivec3 LOD_square =  lod1/ivec3(1,2,1) ;
                      bool top_slab; 
			          if( LOD_square != last_lod1)
			          {//load lod chunk, we are in a different one
                      
                        top_slab = modi(lod1.y,2) == 1;
                        lod1.y -= top_slab?1:0;
				        lod_chunk = imageLoad( c_image_voxel_lod_1, lod1 ).r;
				        lod_chunk2 = imageLoad( c_image_voxel_lod_1, lod1+ivec3(0,1,0) ).r;
				        last_lod1 = lod1;
			          }
			          
			          ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
			          uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                             + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                             + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
			          
		              this_ray.hit_something = (( (top_slab? lod_chunk2 : lod_chunk) >> bit_offset_in_the_LOD) & 1u) != 0u ;
                      
                 #else
                      ivec3 lod1 = voxel_pos / Voxel_bitmask_lod_size;
			          if( lod1 != last_lod1 )
			          {//load lod chunk, we are in a different one
				        lod_chunk = imageLoad( c_image_voxel_lod_1, lod1 ).r;
				        last_lod1 = lod1;
			          }
			          
			          ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
			          uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                             + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                             + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
			          
		              this_ray.hit_something = ((lod_chunk >> bit_offset_in_the_LOD) & 1u) != 0u ;
                #endif
			   
			#else
                //get data, unpack, visualize
                uint integerValue = imageLoad(cimage1,voxel_pos ).r;
                
                this_ray.hit_something = integerValue != 0u;
            
            #endif

        }//>in range
        
    }//>rt loop

    if(this_ray.hit_something)
    {
        //approximated scene, we will later replace this with different data to work with textures
	    this_ray.albedo = unpackUnorm4x8( imageLoad(cimage1,voxel_pos ).r );
        
        //normals
		vec3 v_normal = last_dda_pos-ivec3(dda_pos);

        this_ray.normals_face = vec3(v_normal);
        
        //< Textures
        #if TEXTURES_IN_RT > 0
			//we have a 2x2x2 3d data structure of 8 cubes as big as the VOXEL_AREA, so we need to offset into the one we are using
			ivec3 buffer_channel_offset = ivec3(0,0,VOXEL_AREA);
            //position in the block is being used as the local texture coords
			vec3 uv_pos = 1.-fract(pos);
			//load the saved texture UVs from the voxel scene
			vec4 uv_pos2 = unpack_uv_buffer( imageLoad(c_image4_voxel_scene, voxel_pos +buffer_channel_offset ).r );
            //which local position coords to use depends on the face direction					
            uv_pos.xy = v_normal.y != 0 ? uv_pos.xz : v_normal.z != 0 ? uv_pos.xy : uv_pos.zy;
            //load texture from the bound atlas by reconstructing the UVs
			vec4 v_texture = textureLod(atlas_a,uv_pos2.xy +uv_pos.xy*uv_pos2.ba,0);
				
			//gl color
			vec3 glcolor = unpack_uv_buffer_channel_3( imageLoad(c_image4_voxel_scene, voxel_pos 
                +ivec3(0,VOXEL_AREA,VOXEL_AREA) //offset for gl color in the 2x2x2 Voxel Scene
                 ).r );
			v_texture.rgb = v_texture.rgb * glcolor; 

			this_ray.albedo = v_texture;

            //to do:
                //specular texture
                //normals texture
		#endif
        //> Textures
    }
    
    ///debug area
    
    //return to player_space
    pos-=VOXEL_AREA/2+fract(cameraPosition);

    //output result
    this_ray.pos = pos;
    this_ray.dir = dir;
    return this_ray;
}
#endif
