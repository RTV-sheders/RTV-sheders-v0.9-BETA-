// MIT License: Do Whatever you want to with this code as long as this line stays in the file. This file contains code Copyright © 2026 timetravelbeard (contact: https://www.patreon.com/timetravelbeard , https://youtube.com/@timetravelbeard3588 , https://discord.gg/S6F4r6K5yU )  Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

#if VOXEL_LODS >= 1

    // Dependencies
       	#include "/stuff/misc_functions.glsl"

    // Access our 3D texture
        // image.c_image_voxel_lod_1 = cSamplerVoxelLod_1 RED_INTEGER R32UI UNSIGNED_INT true false 128 128 128
    	layout (r32ui) uniform uimage3D c_image_voxel_lod_1;
	
    // Global Variables
        const ivec3 Voxel_bitmask_lod_size = ivec3(4,2,4); //this is here as a convenience, so we can easily change it later
        const ivec3 Voxel_bitmask_lod_offsets = ivec3(1,16,4); // how much offset each coordinate represents in where they are packed in the LOD

    // Functions
    void write_to_voxel_lod(in ivec3 voxel_pos)
    {
        //lod is 32 blocks in one 32uint, aligned as a 4x2x4, defined as global variable Voxel_bitmask_lod_size
	    //set binary lod mask 
	      uint lod_mask = 0u; //empty
	      ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
	      uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                     + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                     + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
	    
        //add this voxel to the mask  
	      lod_mask = lod_mask | (1u << bit_offset_in_the_LOD);

        //write this voxel to the bitmask LOD, imageAtomicOr lets us write to one bit while keeping the other bits already there intact
	      imageAtomicOr( c_image_voxel_lod_1, voxel_pos/ Voxel_bitmask_lod_size , lod_mask);	
	   
    }

    void read_from_voxel_lod(in ivec3 voxel_pos)
    { // this is an example of how to read, the actual code used is in stuff/rt/rt4.glsl and probably later rt versions
	
        //keep where we were so we can track when we are in another LOD chunk
        ivec3 last_lod1;

        //which LOD chunk to check
              uint lod_chunk;
			  ivec3 lod1 =voxel_pos / Voxel_bitmask_lod_size;
			  if( lod1 != last_lod1 )
			  {//load lod chunk, we are in a different one
				lod_chunk = imageLoad( c_image_voxel_lod_1, lod1 ).r;
				last_lod1 = lod1;
			  }
			  
			  ivec3 location_within_an_LOD = modiv(voxel_pos,Voxel_bitmask_lod_size); 
			  uint bit_offset_in_the_LOD = location_within_an_LOD.x * Voxel_bitmask_lod_offsets.x
                                     + location_within_an_LOD.y * Voxel_bitmask_lod_offsets.y
                                     + location_within_an_LOD.z * Voxel_bitmask_lod_offsets.z; 
			  
		  if( ((lod_chunk >> bit_offset_in_the_LOD) & 1u) !=0u)
		  {//voxel is occupied
            }
    }
#endif
