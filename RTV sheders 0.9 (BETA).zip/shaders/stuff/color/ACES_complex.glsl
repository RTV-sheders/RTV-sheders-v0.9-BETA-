//=================================================================================================
//
//  Baking Lab
//  by MJP and David Neubelt
//  http://mynameismjp.wordpress.com/
//
//  All code licensed under the MIT license
//  edited for glsl by timetravelbeard
//
//=================================================================================================

// The code in this file was originally written by Stephen Hill (@self_shadow), who deserves all
// credit for coming up with this fit and implementing it. Buy him a beer next time you see him. :)

// sRGB => XYZ => D65_2_D60 => AP1 => RRT_SAT
const mat3 ACESInputMat =
{
    {0.59719, 0.35458, 0.04823},
    {0.07600, 0.90834, 0.01566},
    {0.02840, 0.13383, 0.83777}
};

// ODT_SAT => XYZ => D60_2_D65 => sRGB
const mat3 ACESOutputMat =
{
    { 1.60475, -0.53108, -0.07367},
    {-0.10208,  1.10813, -0.00605},
    {-0.00327, -0.07276,  1.07602}
};

vec3 RRTAndODTFit(vec3 v)
{
    vec3 a = v * (v + 0.0245786f) - 0.000090537f;
    vec3 b = v * (0.983729f * v + 0.4329510f) + 0.238081f;
    return a / b;
}

vec3 ACESFitted(vec3 color)
{
     color = color * ACESInputMat;

    // Apply RRT and ODT
    color = RRTAndODTFit(color);

     color =  color * ACESOutputMat;

    // Clamp to [0, 1]
    color = clamp(color,0.,1.);

    return color;
}

vec3 ACESFitted_inverted(vec3 color)
{
    color = ACESInputMat* color;

    // Apply RRT and ODT
    color = RRTAndODTFit(color);

   color = ACESOutputMat * color;

    // Clamp to [0, 1]
    color = clamp(color,0.,1.);

    return color;
}